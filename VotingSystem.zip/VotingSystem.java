package CodeMore;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
public class VotingSystem {
	private static Map<String, Integer> candidates = new HashMap<>();
	public static void main(String[] args) {
		candidates.put("Aman", 1);
		candidates.put("Babulal", 2);
		candidates.put("Chandan", 3);
		Scanner scanner = new Scanner(System.in);
		boolean votingOpen = true;
		while (votingOpen) {
			System.out.println("Welcome to the Voting System!");
			System.out.println("Please vote for one of the following candidates:");
			for (String candidate : candidates.keySet()) {
				System.out.println(candidate);
			}
			System.out.println("Type 'exit' to finish voting.");

			String vote = scanner.nextLine();

			if (vote.equalsIgnoreCase("exit")) {
				votingOpen = false;
			} else if (candidates.containsKey(vote)) {
				candidates.put(vote, candidates.get(vote) + 1);
				System.out.println("Thank you for voting for " + vote + "!");
			} else {
				System.out.println("Invalid candidate. Please try again.");
			}
		}
		scanner.close();
		printResults();
	}
	private static void printResults() {
		System.out.println("\nVoting Results:");
		for (Map.Entry<String, Integer> entry : candidates.entrySet()) {
			System.out.println(entry.getKey() + ": " + entry.getValue() + " votes");
		}
		String winner = null;
		int maxVotes = 0;
		for (Map.Entry<String, Integer> entry : candidates.entrySet()) {
			if (entry.getValue() > maxVotes) {
				maxVotes = entry.getValue();
				winner = entry.getKey();
			}
		}
		if (winner != null) {
			System.out.println("The winner is: " + winner + " with " + maxVotes + " votes!");
		} else {
			System.out.println("No votes were cast.");
		}
	}
}
